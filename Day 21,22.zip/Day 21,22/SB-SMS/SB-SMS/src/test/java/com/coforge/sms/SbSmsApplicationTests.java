package com.coforge.sms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbSmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
