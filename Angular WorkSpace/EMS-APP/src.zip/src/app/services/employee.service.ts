import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from '../models/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  emsUrl: string = '/api/v1/ems';
  constructor(private http: HttpClient) { }

    insertEmployee(employee: Employee) {
      return this.http.post(this.emsUrl + "/employees", employee).subscribe(
        (response) => {
          console.log('Employee inserted successfully:', response);
        },
        (error) => {
          console.error('Error inserting employee:', error);
        }
      );
    }
}
