import { Component } from '@angular/core';
import { EmployeeService } from '../../services/employee.service';
import { Employee } from '../../models/employee';

@Component({
  selector: 'app-employee',
  standalone: false,
  templateUrl: './employee.html',
  styleUrl: './employee.css',
})
export class EmployeeComponent {

  employee: Employee;

  constructor(private employeeService: EmployeeService) {
    this.employee = new Employee();
  }

  insertEmployee(data: any) {
    this.employee.eid = data.eid;
    this.employee.ename = data.ename;
  this.employee.esalary = data.esalary;
  this.employee.dno = data.dno;

    this.employeeService.insertEmployee(this.employee);
  }
}