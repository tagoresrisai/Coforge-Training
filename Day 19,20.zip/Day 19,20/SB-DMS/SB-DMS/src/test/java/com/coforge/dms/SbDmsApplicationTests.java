package com.coforge.dms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbDmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
